//>>built
define("dojox/flash",["./flash/_base"],function(){});