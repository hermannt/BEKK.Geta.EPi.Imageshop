//>>built
define("dojo/request",["./request/default!"],function(_1){return _1;});